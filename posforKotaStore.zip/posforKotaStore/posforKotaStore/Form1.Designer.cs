﻿
namespace posforKotaStore
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnC = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.btnKotaSmall = new System.Windows.Forms.Button();
            this.btnKotaLarge = new System.Windows.Forms.Button();
            this.btnKotaMed = new System.Windows.Forms.Button();
            this.btnBigPizza = new System.Windows.Forms.Button();
            this.btnCoke = new System.Windows.Forms.Button();
            this.btnGwinya = new System.Windows.Forms.Button();
            this.btnPizza = new System.Windows.Forms.Button();
            this.btnBurgerSmall = new System.Windows.Forms.Button();
            this.btnBurger = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtMethod = new System.Windows.Forms.ComboBox();
            this.txtChange = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtCost = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.txtTax = new System.Windows.Forms.TextBox();
            this.txtSubTotal = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnC);
            this.panel1.Controls.Add(this.button28);
            this.panel1.Controls.Add(this.button30);
            this.panel1.Controls.Add(this.button10);
            this.panel1.Controls.Add(this.button16);
            this.panel1.Controls.Add(this.button11);
            this.panel1.Controls.Add(this.button18);
            this.panel1.Controls.Add(this.button12);
            this.panel1.Controls.Add(this.button17);
            this.panel1.Controls.Add(this.button13);
            this.panel1.Controls.Add(this.button15);
            this.panel1.Controls.Add(this.button14);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(308, 390);
            this.panel1.TabIndex = 0;
            // 
            // btnC
            // 
            this.btnC.AutoSize = true;
            this.btnC.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC.Location = new System.Drawing.Point(230, 300);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(75, 51);
            this.btnC.TabIndex = 21;
            this.btnC.Text = "C";
            this.btnC.UseVisualStyleBackColor = true;
            this.btnC.Click += new System.EventHandler(this.btnC_Click);
            // 
            // button28
            // 
            this.button28.AutoSize = true;
            this.button28.Location = new System.Drawing.Point(26, 299);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(78, 52);
            this.button28.TabIndex = 20;
            this.button28.Text = "0";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.digits);
            // 
            // button30
            // 
            this.button30.AutoSize = true;
            this.button30.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.Location = new System.Drawing.Point(127, 300);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(75, 51);
            this.button30.TabIndex = 18;
            this.button30.Text = ".";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.digits);
            // 
            // button10
            // 
            this.button10.AutoSize = true;
            this.button10.Location = new System.Drawing.Point(26, 205);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(78, 52);
            this.button10.TabIndex = 17;
            this.button10.Text = "1";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.digits);
            // 
            // button16
            // 
            this.button16.AutoSize = true;
            this.button16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.Location = new System.Drawing.Point(26, 41);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(79, 53);
            this.button16.TabIndex = 11;
            this.button16.Text = "7";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.digits);
            // 
            // button11
            // 
            this.button11.AutoSize = true;
            this.button11.Location = new System.Drawing.Point(225, 206);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 51);
            this.button11.TabIndex = 16;
            this.button11.Text = "3";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.digits);
            // 
            // button18
            // 
            this.button18.AutoSize = true;
            this.button18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.Location = new System.Drawing.Point(127, 42);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(75, 51);
            this.button18.TabIndex = 9;
            this.button18.Text = "8";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.digits);
            // 
            // button12
            // 
            this.button12.AutoSize = true;
            this.button12.Location = new System.Drawing.Point(127, 206);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 51);
            this.button12.TabIndex = 15;
            this.button12.Text = "2";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.digits);
            // 
            // button17
            // 
            this.button17.AutoSize = true;
            this.button17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.Location = new System.Drawing.Point(225, 42);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(75, 51);
            this.button17.TabIndex = 10;
            this.button17.Text = "9";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.digits);
            // 
            // button13
            // 
            this.button13.AutoSize = true;
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.Location = new System.Drawing.Point(26, 113);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(78, 52);
            this.button13.TabIndex = 14;
            this.button13.Text = "4";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.digits);
            // 
            // button15
            // 
            this.button15.AutoSize = true;
            this.button15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.Location = new System.Drawing.Point(127, 114);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 51);
            this.button15.TabIndex = 12;
            this.button15.Text = "5";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.digits);
            // 
            // button14
            // 
            this.button14.AutoSize = true;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.Location = new System.Drawing.Point(225, 114);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 51);
            this.button14.TabIndex = 13;
            this.button14.Text = "6";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.digits);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Controls.Add(this.button22);
            this.panel2.Controls.Add(this.button23);
            this.panel2.Controls.Add(this.button24);
            this.panel2.Controls.Add(this.btnKotaSmall);
            this.panel2.Controls.Add(this.btnKotaLarge);
            this.panel2.Controls.Add(this.btnKotaMed);
            this.panel2.Controls.Add(this.btnBigPizza);
            this.panel2.Controls.Add(this.btnCoke);
            this.panel2.Controls.Add(this.btnGwinya);
            this.panel2.Controls.Add(this.btnPizza);
            this.panel2.Controls.Add(this.btnBurgerSmall);
            this.panel2.Controls.Add(this.btnBurger);
            this.panel2.Location = new System.Drawing.Point(344, 25);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(406, 409);
            this.panel2.TabIndex = 1;
            // 
            // button22
            // 
            this.button22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.Image = ((System.Drawing.Image)(resources.GetObject("button22.Image")));
            this.button22.Location = new System.Drawing.Point(250, 160);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(63, 64);
            this.button22.TabIndex = 14;
            this.button22.Text = "R15";
            this.button22.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button23
            // 
            this.button23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.Image = ((System.Drawing.Image)(resources.GetObject("button23.Image")));
            this.button23.Location = new System.Drawing.Point(416, 160);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(63, 64);
            this.button23.TabIndex = 13;
            this.button23.Text = "R75";
            this.button23.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.Image = ((System.Drawing.Image)(resources.GetObject("button24.Image")));
            this.button24.Location = new System.Drawing.Point(334, 160);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(63, 64);
            this.button24.TabIndex = 12;
            this.button24.Text = "R22";
            this.button24.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // btnKotaSmall
            // 
            this.btnKotaSmall.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)), true);
            this.btnKotaSmall.Image = ((System.Drawing.Image)(resources.GetObject("btnKotaSmall.Image")));
            this.btnKotaSmall.Location = new System.Drawing.Point(250, 41);
            this.btnKotaSmall.Name = "btnKotaSmall";
            this.btnKotaSmall.Size = new System.Drawing.Size(63, 64);
            this.btnKotaSmall.TabIndex = 11;
            this.btnKotaSmall.Text = "R10";
            this.btnKotaSmall.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnKotaSmall.UseVisualStyleBackColor = true;
            this.btnKotaSmall.Click += new System.EventHandler(this.btnKotaSmall_Click);
            // 
            // btnKotaLarge
            // 
            this.btnKotaLarge.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKotaLarge.Image = ((System.Drawing.Image)(resources.GetObject("btnKotaLarge.Image")));
            this.btnKotaLarge.Location = new System.Drawing.Point(416, 41);
            this.btnKotaLarge.Name = "btnKotaLarge";
            this.btnKotaLarge.Size = new System.Drawing.Size(63, 64);
            this.btnKotaLarge.TabIndex = 10;
            this.btnKotaLarge.Text = "R45";
            this.btnKotaLarge.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btnKotaLarge.UseVisualStyleBackColor = true;
            // 
            // btnKotaMed
            // 
            this.btnKotaMed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKotaMed.Image = ((System.Drawing.Image)(resources.GetObject("btnKotaMed.Image")));
            this.btnKotaMed.Location = new System.Drawing.Point(334, 41);
            this.btnKotaMed.Name = "btnKotaMed";
            this.btnKotaMed.Size = new System.Drawing.Size(63, 64);
            this.btnKotaMed.TabIndex = 9;
            this.btnKotaMed.Text = "R20";
            this.btnKotaMed.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btnKotaMed.UseVisualStyleBackColor = true;
            this.btnKotaMed.Click += new System.EventHandler(this.button27_Click);
            // 
            // btnBigPizza
            // 
            this.btnBigPizza.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBigPizza.Image = ((System.Drawing.Image)(resources.GetObject("btnBigPizza.Image")));
            this.btnBigPizza.Location = new System.Drawing.Point(9, 160);
            this.btnBigPizza.Name = "btnBigPizza";
            this.btnBigPizza.Size = new System.Drawing.Size(63, 64);
            this.btnBigPizza.TabIndex = 5;
            this.btnBigPizza.Text = "R70";
            this.btnBigPizza.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btnBigPizza.UseVisualStyleBackColor = true;
            this.btnBigPizza.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnCoke
            // 
            this.btnCoke.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCoke.Image = ((System.Drawing.Image)(resources.GetObject("btnCoke.Image")));
            this.btnCoke.Location = new System.Drawing.Point(178, 160);
            this.btnCoke.Name = "btnCoke";
            this.btnCoke.Size = new System.Drawing.Size(63, 64);
            this.btnCoke.TabIndex = 4;
            this.btnCoke.Text = "R15";
            this.btnCoke.UseVisualStyleBackColor = true;
            this.btnCoke.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnGwinya
            // 
            this.btnGwinya.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGwinya.Image = ((System.Drawing.Image)(resources.GetObject("btnGwinya.Image")));
            this.btnGwinya.Location = new System.Drawing.Point(96, 160);
            this.btnGwinya.Name = "btnGwinya";
            this.btnGwinya.Size = new System.Drawing.Size(63, 64);
            this.btnGwinya.TabIndex = 3;
            this.btnGwinya.Text = "R2";
            this.btnGwinya.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btnGwinya.UseVisualStyleBackColor = true;
            this.btnGwinya.Click += new System.EventHandler(this.btnGwinya_Click);
            // 
            // btnPizza
            // 
            this.btnPizza.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPizza.BackgroundImage")));
            this.btnPizza.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPizza.Image = ((System.Drawing.Image)(resources.GetObject("btnPizza.Image")));
            this.btnPizza.Location = new System.Drawing.Point(9, 41);
            this.btnPizza.Name = "btnPizza";
            this.btnPizza.Size = new System.Drawing.Size(63, 64);
            this.btnPizza.TabIndex = 2;
            this.btnPizza.Text = "R10";
            this.btnPizza.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPizza.UseVisualStyleBackColor = true;
            this.btnPizza.Click += new System.EventHandler(this.btnPizza_Click);
            // 
            // btnBurgerSmall
            // 
            this.btnBurgerSmall.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBurgerSmall.Image = ((System.Drawing.Image)(resources.GetObject("btnBurgerSmall.Image")));
            this.btnBurgerSmall.Location = new System.Drawing.Point(178, 41);
            this.btnBurgerSmall.Name = "btnBurgerSmall";
            this.btnBurgerSmall.Size = new System.Drawing.Size(63, 64);
            this.btnBurgerSmall.TabIndex = 1;
            this.btnBurgerSmall.Text = "R20";
            this.btnBurgerSmall.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnBurgerSmall.UseVisualStyleBackColor = true;
            this.btnBurgerSmall.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnBurger
            // 
            this.btnBurger.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBurger.Image = ((System.Drawing.Image)(resources.GetObject("btnBurger.Image")));
            this.btnBurger.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnBurger.Location = new System.Drawing.Point(96, 41);
            this.btnBurger.Name = "btnBurger";
            this.btnBurger.Size = new System.Drawing.Size(63, 64);
            this.btnBurger.TabIndex = 0;
            this.btnBurger.Text = "R30";
            this.btnBurger.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnBurger.UseVisualStyleBackColor = true;
            this.btnBurger.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(12, 427);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1203, 152);
            this.panel3.TabIndex = 2;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel6.Controls.Add(this.btnRemove);
            this.panel6.Controls.Add(this.btnPrint);
            this.panel6.Controls.Add(this.btnReset);
            this.panel6.Controls.Add(this.button31);
            this.panel6.Location = new System.Drawing.Point(666, 15);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(349, 115);
            this.panel6.TabIndex = 2;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // btnRemove
            // 
            this.btnRemove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove.Location = new System.Drawing.Point(185, 66);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(157, 45);
            this.btnRemove.TabIndex = 3;
            this.btnRemove.Text = "Cancel";
            this.btnRemove.UseVisualStyleBackColor = false;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.Location = new System.Drawing.Point(3, 68);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(176, 43);
            this.btnPrint.TabIndex = 2;
            this.btnPrint.Text = "Receipt";
            this.btnPrint.UseVisualStyleBackColor = false;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(185, 3);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(157, 57);
            this.btnReset.TabIndex = 1;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button31.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button31.Location = new System.Drawing.Point(3, 8);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(176, 52);
            this.button31.TabIndex = 0;
            this.button31.Text = "Pay";
            this.button31.UseVisualStyleBackColor = false;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.txtMethod);
            this.panel5.Controls.Add(this.txtChange);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Controls.Add(this.txtCost);
            this.panel5.Controls.Add(this.label11);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Location = new System.Drawing.Point(329, 13);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(294, 115);
            this.panel5.TabIndex = 1;
            // 
            // txtMethod
            // 
            this.txtMethod.FormattingEnabled = true;
            this.txtMethod.Items.AddRange(new object[] {
            "Card",
            "Cash",
            "Credit"});
            this.txtMethod.Location = new System.Drawing.Point(154, 12);
            this.txtMethod.Name = "txtMethod";
            this.txtMethod.Size = new System.Drawing.Size(121, 21);
            this.txtMethod.TabIndex = 13;
            // 
            // txtChange
            // 
            this.txtChange.Location = new System.Drawing.Point(154, 90);
            this.txtChange.Name = "txtChange";
            this.txtChange.Size = new System.Drawing.Size(121, 20);
            this.txtChange.TabIndex = 12;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(17, 80);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(115, 31);
            this.label10.TabIndex = 3;
            this.label10.Text = "Change";
            // 
            // txtCost
            // 
            this.txtCost.Location = new System.Drawing.Point(154, 53);
            this.txtCost.Name = "txtCost";
            this.txtCost.Size = new System.Drawing.Size(121, 20);
            this.txtCost.TabIndex = 11;
            this.txtCost.Text = "0";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(17, 41);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 31);
            this.label11.TabIndex = 2;
            this.label11.Text = "Cost";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(17, 10);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(110, 31);
            this.label12.TabIndex = 1;
            this.label12.Text = "Method";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.txtTotal);
            this.panel4.Controls.Add(this.txtTax);
            this.panel4.Controls.Add(this.txtSubTotal);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Location = new System.Drawing.Point(14, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(294, 115);
            this.panel4.TabIndex = 0;
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(162, 88);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(101, 20);
            this.txtTotal.TabIndex = 9;
            // 
            // txtTax
            // 
            this.txtTax.Location = new System.Drawing.Point(162, 51);
            this.txtTax.Name = "txtTax";
            this.txtTax.Size = new System.Drawing.Size(101, 20);
            this.txtTax.TabIndex = 8;
            // 
            // txtSubTotal
            // 
            this.txtSubTotal.Location = new System.Drawing.Point(162, 18);
            this.txtSubTotal.Name = "txtSubTotal";
            this.txtSubTotal.Size = new System.Drawing.Size(101, 20);
            this.txtSubTotal.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(17, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 31);
            this.label3.TabIndex = 3;
            this.label3.Text = "Total";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 31);
            this.label2.TabIndex = 2;
            this.label2.Text = "Tax";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "Sub Total";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Maroon;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            this.dataGridView1.Location = new System.Drawing.Point(815, 25);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(357, 386);
            this.dataGridView1.TabIndex = 3;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Item";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Qty";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Amount";
            this.Column3.Name = "Column3";
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            this.printPreviewDialog1.Load += new System.EventHandler(this.printPreviewDialog1_Load);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnBurgerSmall;
        private System.Windows.Forms.Button btnBurger;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.Button btnBigPizza;
        private System.Windows.Forms.Button btnCoke;
        private System.Windows.Forms.Button btnGwinya;
        private System.Windows.Forms.Button btnPizza;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button btnKotaSmall;
        private System.Windows.Forms.Button btnKotaLarge;
        private System.Windows.Forms.Button btnKotaMed;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox txtMethod;
        private System.Windows.Forms.TextBox txtChange;
        private System.Windows.Forms.TextBox txtCost;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.TextBox txtTax;
        private System.Windows.Forms.TextBox txtSubTotal;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.Button btnC;
    }
}

